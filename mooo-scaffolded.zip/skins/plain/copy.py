# skins/plain/copy.py
# ──────────────────────────────────────────────────────────────────────
# Plain / "Pearl Drop" skin: clean, warm, minimal.
# Very few overrides — mostly just the brand identity swap.
# ──────────────────────────────────────────────────────────────────────

COPY = {
    "brand.name":                  "Pearl Drop",
    "brand.tagline":               "Your gentle lactation companion",
    "brand.emoji":                 "💧",

    "nav.home":                    "Home",
    "nav.pump":                    "Pump",
    "nav.supplements":             "Supplements",
    "nav.daily":                   "Daily",
    "nav.progress":                "Progress",

    "home.welcome":                "Welcome to Pearl Drop 🫧",

    "footer.message":              "Made with care for your lactation journey · All data stays private",
}
