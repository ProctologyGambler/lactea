# Mooo 🐮

A personal tracking app for people inducing lactation without pregnancy — adoptive parents, trans women, non-gestational parents, and others. Track pumping sessions, supplements, and how your body responds over time. Understand your patterns. Use a skin that speaks your language.

> ⚕️ **This is not medical advice.** Mooo is an informational and personal-tracking tool. Inducing lactation should always be done under the supervision of a healthcare provider or IBCLC. See `/privacy/` for what happens to your data.

## What makes Mooo different

Most health trackers treat lactation induction as an edge case. Mooo is built around it.

**Skins, not themes.** Each skin changes the entire experience — visuals, language, sound, and which information feels most important. The cow skin is playful and encouraging. The clinical skin is evidence-first and IBCLC-friendly. Each one says *this was made for you* to a different community of practice.

**Your body, your field notes.** The daily log isn't just "how do you feel." It's a lightweight self-study — mood, energy, sleep, hydration, and your own custom tags. Over time, the app connects these dots with your pumping output and supplement use to surface patterns you wouldn't see in a spreadsheet.

**Evidence you can evaluate.** The supplement guide doesn't just say "research-backed." It tells you what the research actually found, how strong it is, and where the gaps are — in language that makes sense whether you're talking to your IBCLC or your partner.

## Features

- **Pump timer** — stopwatch-style session logging with per-breast ml and notes. Today's totals at a glance.
- **Field log** — daily multi-signal check-in: mood, body state, energy, sleep, hydration, stress, and custom tags.
- **Supplement tracker** — daily checklist, quick-add presets, per-day toggle.
- **Supplement guide** — research-grounded reference with dosages, evidence quality, side effects, and sourced citations.
- **Insights** — correlations between your supplements, daily state, and pumping output. Plain-language pattern summaries.
- **Progress** — output trends over 7/30/90 days.
- **CSV export** — download all your data anytime.
- **Skins** — swappable experiential frames for different communities (cow, plain, clinical, and more coming).
- **PWA** — installable to home screen, works offline.

## Tech stack

- **Backend:** Django 5.x, SQLite
- **Frontend:** Tailwind CSS (Play CDN, vendored), Chart.js 4.x, HTMX
- **PWA:** Web App Manifest + service worker with offline caching
- **Production:** WhiteNoise (static files), Gunicorn (WSGI)

## Setup

```bash
git clone <repo-url> mooo && cd mooo
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Generate a secret key:
python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"
# Paste it into .env as SECRET_KEY
python manage.py migrate
python manage.py runserver
```

Open http://127.0.0.1:8000.

## Project docs

- **`DESIGN_BRIEF.md`** — product vision, skin system architecture, and implementation guidance.
- **`ONBOARDING.md`** — codebase walkthrough for new contributors.
- **`task.md`** — running decision log and session notes.

## Privacy

No third-party analytics, no tracking, no external CDNs at runtime. Data lives on the server today (SQLite); the long-term direction is local-first, with data on your device. See `/privacy/` for the current policy.

## Status

Personal prototype under active development. Single user, not production-ready, not on an app store yet.

## License

MIT
