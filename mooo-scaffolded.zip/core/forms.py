from django import forms
from .models import PumpingSession, Supplement, DailyLog

# Shared CSS classes — use skin-neutral names, styled via CSS variables
_input_cls = 'skin-input w-full rounded-2xl px-4 py-3'
_textarea_cls = 'skin-input w-full rounded-3xl px-4 py-3'


class PumpingSessionForm(forms.ModelForm):
    class Meta:
        model = PumpingSession
        fields = ['duration_minutes', 'left_ml', 'right_ml', 'notes']
        widgets = {
            'duration_minutes': forms.HiddenInput(),
            'left_ml': forms.NumberInput(attrs={
                'class': _input_cls,
                'placeholder': '0',
                'min': '0',
            }),
            'right_ml': forms.NumberInput(attrs={
                'class': _input_cls,
                'placeholder': '0',
                'min': '0',
            }),
            'notes': forms.Textarea(attrs={
                'class': _textarea_cls,
                'placeholder': 'Felt good today...',
                'rows': 3,
            }),
        }


class SupplementForm(forms.ModelForm):
    class Meta:
        model = Supplement
        fields = ['name', 'dosage', 'frequency', 'notes']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': _input_cls,
                'placeholder': 'Fenugreek',
            }),
            'dosage': forms.TextInput(attrs={
                'class': _input_cls,
                'placeholder': '610 mg',
            }),
            'frequency': forms.TextInput(attrs={
                'class': _input_cls,
                'placeholder': 'three times daily',
            }),
            'notes': forms.Textarea(attrs={
                'class': _textarea_cls,
                'placeholder': 'with meals',
                'rows': 2,
            }),
        }


class DailyLogForm(forms.ModelForm):
    """Handles notes + the new field-journal fields.
    Mood and breast_feeling are posted as separate preset-checkbox +
    custom-text inputs and combined into comma-strings in the view."""

    class Meta:
        model = DailyLog
        fields = ['energy', 'sleep_quality', 'hydration', 'stress', 'tags', 'notes']
        widgets = {
            'energy': forms.RadioSelect(attrs={'class': 'skin-radio-group'}),
            'sleep_quality': forms.RadioSelect(attrs={'class': 'skin-radio-group'}),
            'hydration': forms.RadioSelect(attrs={'class': 'skin-radio-group'}),
            'stress': forms.RadioSelect(attrs={'class': 'skin-radio-group'}),
            'tags': forms.TextInput(attrs={
                'class': _input_cls,
                'placeholder': 'Custom tags — comma-separated (e.g. cycle-day-14, new-pump)',
            }),
            'notes': forms.Textarea(attrs={
                'class': _textarea_cls,
                'placeholder': "How are you feeling? Anything to remember about today?",
                'rows': 4,
            }),
        }
