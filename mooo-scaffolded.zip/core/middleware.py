"""
core/middleware.py — Skin middleware.

Reads the `skin` cookie on every request, validates it against installed
skins, and sets `request.skin` for templates and views.
"""

from skins.loader import get_available_skins

SKIN_COOKIE = "skin"
SKIN_DEFAULT = "plain"

# Build SKIN_CHOICES dynamically from installed skins.
# This is evaluated once at import time. If you add a skin folder,
# restart the dev server.
SKIN_CHOICES = tuple(s["name"] for s in get_available_skins()) or ("plain",)


def is_valid_skin(value):
    return value in SKIN_CHOICES


class SkinMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        value = request.COOKIES.get(SKIN_COOKIE)
        request.skin = value if is_valid_skin(value) else SKIN_DEFAULT
        return self.get_response(request)
