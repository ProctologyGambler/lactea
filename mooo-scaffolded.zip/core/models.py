from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Profile"


class PumpingSession(models.Model):
    date = models.DateTimeField(default=timezone.now)
    duration_minutes = models.PositiveIntegerField()
    left_ml = models.PositiveIntegerField(default=0)
    right_ml = models.PositiveIntegerField(default=0)
    total_ml = models.PositiveIntegerField(default=0)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date']

    def __str__(self):
        return f"{self.date.date()} - {self.total_ml}ml"


class DailyLog(models.Model):
    ENERGY_CHOICES = [
        (1, 'Very low'),
        (2, 'Low'),
        (3, 'Moderate'),
        (4, 'Good'),
        (5, 'Great'),
    ]
    SLEEP_CHOICES = [
        (1, 'Terrible'),
        (2, 'Poor'),
        (3, 'Okay'),
        (4, 'Good'),
        (5, 'Great'),
    ]
    HYDRATION_CHOICES = [
        (1, 'Dehydrated'),
        (2, 'Could be better'),
        (3, 'Well hydrated'),
    ]
    STRESS_CHOICES = [
        (1, 'Very low'),
        (2, 'Low'),
        (3, 'Moderate'),
        (4, 'High'),
        (5, 'Very high'),
    ]

    date = models.DateField(unique=True)
    breast_feeling = models.CharField(max_length=200, blank=True)
    mood = models.CharField(max_length=200, blank=True)
    energy = models.PositiveSmallIntegerField(choices=ENERGY_CHOICES, null=True, blank=True)
    sleep_quality = models.PositiveSmallIntegerField(choices=SLEEP_CHOICES, null=True, blank=True)
    hydration = models.PositiveSmallIntegerField(choices=HYDRATION_CHOICES, null=True, blank=True)
    stress = models.PositiveSmallIntegerField(choices=STRESS_CHOICES, null=True, blank=True)
    tags = models.CharField(max_length=500, blank=True, help_text="Comma-separated custom tags")
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date']

    def __str__(self):
        return str(self.date)

    @property
    def mood_list(self):
        return [p.strip() for p in self.mood.split(',') if p.strip()] if self.mood else []

    @property
    def breast_feeling_list(self):
        return [p.strip() for p in self.breast_feeling.split(',') if p.strip()] if self.breast_feeling else []

    @property
    def tags_list(self):
        return [t.strip() for t in self.tags.split(',') if t.strip()] if self.tags else []


class Supplement(models.Model):
    name = models.CharField(max_length=100)
    dosage = models.CharField(max_length=100)
    frequency = models.CharField(max_length=100, blank=True)
    start_date = models.DateField(default=timezone.now)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name


class SupplementLog(models.Model):
    supplement = models.ForeignKey(Supplement, on_delete=models.CASCADE)
    date = models.DateField()
    taken = models.BooleanField(default=True)
    notes = models.TextField(blank=True)

    class Meta:
        unique_together = ('supplement', 'date')