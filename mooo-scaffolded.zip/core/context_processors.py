"""
core/context_processors.py — Inject skin data into every template context.

Provides:
    {{ copy }}          — dict of all user-facing strings for the active skin
    {{ skin_config }}   — full skin.json dict (palette, features, sounds, pwa)
    {{ skin_features }} — just the features dict for convenience
    {{ available_skins }} — list of all installed skins (for theme picker)

Templates access copy like:  {{ copy.brand.name }}
But because Django templates can't do dot-lookup on dict keys with dots,
we use a helper that converts "brand.name" → copy["brand.name"].
So in templates you'd use:  {{ c.brand_name }}  (dots replaced with underscores)

Actually, the cleanest approach: we provide a flat dict with underscored keys
so templates just do {{ c.brand_name }}, {{ c.pump_title }}, etc.
"""

from skins.loader import get_skin_copy, get_skin_config, get_skin_features, get_available_skins


def skin_context(request):
    """Add skin copy + config to the template context."""
    skin_name = getattr(request, "skin", "plain")

    # Get the dot-keyed copy dict and convert to underscore keys
    # so Django templates can access them:  {{ c.brand_name }}
    raw_copy = get_skin_copy(skin_name)
    c = {key.replace(".", "_"): value for key, value in raw_copy.items()}

    return {
        "c": c,
        "skin_config": get_skin_config(skin_name),
        "skin_features": get_skin_features(skin_name),
        "available_skins": get_available_skins(),
    }
