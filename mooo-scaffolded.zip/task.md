# Mooo — Working Log

A running summary of conversations, decisions, and where things stand. Updated by Claude as we work together. Read this any time you want to remember "what were we doing?" or "why did we pick that?"

---

## 2026-05-23 — Project orientation & strategy

**What we did**
- Walked through the repo together so I have a clear picture of the codebase: Django 5 app, SQLite, PWA-ready, with an in-progress "skin" system (cow + plain) sitting uncommitted on `main`.
- Talked about the bigger goal: make Mooo fantastic, support a variety of niche communities through swappable skins, and possibly help fund anthropological work.

**Key decisions / direction**
- **Skins are the core differentiator**, not a cosmetic afterthought. One codebase, multiple skins (visuals + copy + sound + which features feel prominent) for distinct communities of practice.
- **Mobile path: PWA first, Capacitor later.** Stay with the existing PWA (installable to home screen) for now. When/if app-store presence matters, wrap with Capacitor — same codebase, native shell. Avoid a React Native / Flutter rewrite.
- **Architecture guardrails for skins:**
  - Per-skin copy (a small dictionary per skin), not just images/sounds
  - Per-skin palette + fonts via CSS variables
  - A `skin.json` manifest per skin so adding a new one is "drop a folder"

**Open questions for you**
- Which niche communities do you want to design skins around first? (Adoptive parents, trans women, kink/relationship, surrogates, clinical/IBCLC-supervised, others?)
- Do you want this `task.md` file committed to git, or kept local-only? (It may end up containing personal/strategic context.)

**Suggested next steps (in order)**
1. Finish + commit the cow/plain skin work that's currently half-done end-to-end.
2. Fix the small bug I flagged: `set_skin` returns HTTP 405 ("method not allowed") for an invalid skin name — should be 400 or 404.
3. Add per-skin copy (Python dict per skin) so skins differ in words, not just pictures.
4. Sketch the `skin.json` manifest format.
5. Then revisit: PWA-only vs. Capacitor wrap.

**Things I now know about you (saved in memory)**
- New to coding — I'll explain reasoning, not just commands.
- Anthropological background — framing features around "who uses this and how" lands well.
- Mooo may partly fund your anthropological work.

---

<!-- New entries go above this line. Most recent on top. -->
