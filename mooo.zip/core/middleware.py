SKIN_COOKIE = "skin"
SKIN_DEFAULT = "plain"
SKIN_CHOICES = ("plain", "cow")


def is_valid_skin(value):
    return value in SKIN_CHOICES


class SkinMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        value = request.COOKIES.get(SKIN_COOKIE)
        request.skin = value if is_valid_skin(value) else SKIN_DEFAULT
        return self.get_response(request)
